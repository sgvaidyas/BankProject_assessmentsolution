﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bankloanproj.exceptions
{
    class WrongFineness:Exception
    {
        public WrongFineness() : base() { }
        public WrongFineness(string message) : base(message) { }
        public WrongFineness(string message,SystemException inner) : base(message,inner) { }
    }
}
