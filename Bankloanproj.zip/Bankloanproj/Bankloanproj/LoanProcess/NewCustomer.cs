﻿using System;
using Bankloanproj.exceptions;

namespace Bankloanproj.LoanProcess
{
    public class NewCustomer:LendingLoan
    {
        public NewCustomer() : base() { }
        public override float CalculateLoan(int custId, int type, float weight, int fineness)
        {
            int extrafibefees, totalfinecal;
            this.CustId = custId;
            this.type = type;
            loan = 0;

            try
            {
                if (fineness <= 24 && fineness >= 14)
                {
                    extrafibefees = fineness - 14;
                    totalfinecal = 750 + (extrafibefees * 50);

                    loan = weight * totalfinecal;
                    loan = loan - 100;
                }
                else
                    throw new WrongFineness("Wrong fineness Provided ");

            }
            catch (Exception ob)
            {
                Console.WriteLine(ob.Message);
            }

            return loan;
        }

        public override float CalculateLoan(int custId, int type, float weight, int fineness, int fees)
        {
            int extrafibefees, totalfinecal;
            this.CustId = custId;
            this.type = type;
            loan = 0;
            try
            {
                if (fineness <= 24 && fineness >= 14)
                {
                    extrafibefees = fineness - 14;
                    totalfinecal = 750 + (extrafibefees * 50);

                    loan = weight * totalfinecal;
                    loan = loan - fees;
                }
                else
                    throw new WrongFineness("Wrong fineness Provided ");

            }
            catch(Exception ob)
            {
                Console.WriteLine(ob.Message);
            }
            
            
            return loan;
        }

    }
}
