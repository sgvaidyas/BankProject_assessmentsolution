﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bankloanproj.LoanProcess
{
    abstract public class LendingLoan
    {
        public int type, CustId;
        public float loan;

        public LendingLoan()
        {

        }
        public abstract float CalculateLoan(int custId, int type, float weight, int fineness);
        public abstract float CalculateLoan(int custId, int type, float weight, int fineness,int fees);

        public  float LiquidateLoan(int custId, float amount, float liqAmount)
        {
            float pendingamount;
            if(liqAmount<0)
            {
                pendingamount = amount + liqAmount;
            }
            else
            {
                pendingamount = amount;
            }
            return pendingamount;
        }

    }
}
