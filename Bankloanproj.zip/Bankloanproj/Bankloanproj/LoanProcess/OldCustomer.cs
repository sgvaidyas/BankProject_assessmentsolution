﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Bankloanproj.exceptions;

namespace Bankloanproj.LoanProcess
{
    public class OldCustomer:LendingLoan
    {
        public OldCustomer() : base() { }
        public override float CalculateLoan(int custId, int type, float weight, int fineness)
        {
            int extrafibefees, totalfinecal;
            this.CustId = custId;
            this.type = type;
            loan = 0;

            try
            {
                if (fineness <= 24 && fineness >= 14)
                {
                    extrafibefees = fineness - 14;
                    totalfinecal = 750 + (extrafibefees * 50);

                    loan = weight * totalfinecal;
                    
                }
                else
                    throw new WrongFineness("Wrong fineness Provided ");

            }
            catch (Exception ob)
            {
                Console.WriteLine(ob.Message);
            }

            return loan;
        }

        public override float CalculateLoan(int custId, int type, float weight, int fineness, int fees)
        {
            int extrafibefees, totalfinecal;
            this.CustId = custId;
            this.type = type;
            loan = 0;
           
            try
            {
                if (fees != 0)
                    throw new WrongType("Wrong type customer ");
                if (fineness <= 24 && fineness >= 14)
                {
                    extrafibefees = fineness - 14;
                    totalfinecal = 750 + (extrafibefees * 50);

                    loan = weight * totalfinecal;
                    loan = loan - fees;
                }
                else
                    throw new WrongFineness("Wrong fineness Provided ");

            }
            catch (Exception ob)
            {
                Console.WriteLine(ob.Message);
            }
            return loan;
        }

    }
}
