﻿using System;
using Bankloanproj.LoanProcess;

namespace Bankloanproj
{
    class Program
    {
        static void Main(string[] args)
        {
            NewCustomer nc = new NewCustomer();
            Console.WriteLine("LOAN = "+nc.CalculateLoan(111, 1, 22.2f, 19));
            Console.WriteLine("LOAN = " + nc.CalculateLoan(111, 1, 22.2f, 19,250));
            //wrongfineness
            Console.WriteLine("LOAN = " + nc.CalculateLoan(111, 0, 22.2f,8));

            OldCustomer oc = new OldCustomer();
            Console.WriteLine("OLD CUST LOAN = " + oc.CalculateLoan(111, 0, 22.2f, 19));
            Console.WriteLine("OLD CUST LOAN = " + oc.CalculateLoan(111, 0, 22.2f, 19, 250));
            //wrongfineness
            Console.WriteLine("LOAN = " + oc.CalculateLoan(111, 0, 22.2f, 8));


        }
    }
}
