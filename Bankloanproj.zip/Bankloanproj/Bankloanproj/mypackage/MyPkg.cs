﻿using System;
using Bankloanproj.exceptions;
using Bankloanproj.LoanProcess;


namespace Bankloanproj.mypackage
{
    class MyPkg
    {
    }
}
